```javascript
const http = require('http');
const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'exercicios',
    password: '1234',
    port: 5432
});

const server = http.createServer(async (req, res) => {

    if (req.url === '/usuarios') {

        res.setHeader('Content-Type', 'application/json');

        try {

            const resultado = await pool.query(
                'SELECT * FROM usuarios'
            );

            res.end(JSON.stringify(resultado.rows));

        } catch (erro) {

            console.log(erro);

            res.statusCode = 500;

            res.end(JSON.stringify({
                erro: 'Erro ao consultar os usuários'
            }));
        }

        return;
    }

    res.statusCode = 404;

    res.setHeader('Content-Type', 'application/json');

    res.end(JSON.stringify({
        erro: 'Rota não encontrada'
    }));
});

server.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});
```
