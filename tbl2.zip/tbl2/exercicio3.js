const http = require('http');

const produtos = [
    { id: 1, nome: 'Notebook', preco: 3500 },
    { id: 2, nome: 'Mouse', preco: 100 },
    { id: 3, nome: 'Teclado', preco: 200 }
];

const server = http.createServer((req, res) => {

    if (req.url === '/api/produtos') {

        res.setHeader('Content-Type', 'application/json');

        res.end(JSON.stringify(produtos));

        return;
    }

    res.statusCode = 404;

    res.setHeader('Content-Type', 'application/json');

    res.end(JSON.stringify({
        erro: 'Rota não encontrada'
    }));
});

server.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});