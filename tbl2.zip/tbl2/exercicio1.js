const http = require('http');

const server = http.createServer((req, res) => {

    if (req.url.startsWith('/usuario/')) {

        const partes = req.url.split('/');
        const id = Number(partes[2]);

        res.setHeader('Content-Type', 'application/json');

        if (isNaN(id)) {
            res.statusCode = 400;

            res.end(JSON.stringify({
                erro: 'ID inválido'
            }));

            return;
        }

        res.end(JSON.stringify({
            id: id,
            nome: `Usuário ${id}`
        }));

        return;
    }

    res.statusCode = 404;

    res.end(JSON.stringify({
        erro: 'Rota não encontrada'
    }));
});

server.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});