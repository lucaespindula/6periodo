const http = require('http');

const server = http.createServer((req, res) => {

    if (req.url === '/teste') {

        res.setHeader('Content-Type', 'application/json');

        if (req.method === 'GET') {
            res.end(JSON.stringify({
                mensagem: 'Requisição GET realizada com sucesso'
            }));
        } else {
            res.statusCode = 405;

            res.end(JSON.stringify({
                erro: 'Método não permitido'
            }));
        }

    } else {
        res.statusCode = 404;

        res.setHeader('Content-Type', 'application/json');

        res.end(JSON.stringify({
            erro: 'Rota não encontrada'
        }));
    }

});

server.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});