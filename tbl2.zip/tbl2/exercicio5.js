const http = require('http');
const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'tbl2',
    password: 'sql123',
    port: 5432
});

const server = http.createServer(async (req, res) => {

    if (req.url.startsWith('/usuarios/')) {

        const partes = req.url.split('/');
        const id = Number(partes[2]);

        res.setHeader('Content-Type', 'application/json');

        if (isNaN(id)) {
            res.statusCode = 400;

            res.end(JSON.stringify({
                erro: 'ID inválido'
            }));

            return;
        }

        try {

            const resultado = await pool.query(
                'SELECT * FROM usuarios WHERE id = $1',
                [id]
            );

            if (resultado.rows.length === 0) {
                res.statusCode = 404;

                res.end(JSON.stringify({
                    erro: 'Usuário não encontrado'
                }));

                return;
            }

            res.end(JSON.stringify(resultado.rows[0]));

        } catch (erro) {

            console.log(erro);

            res.statusCode = 500;

            res.end(JSON.stringify({
                erro: 'Erro ao consultar o banco de dados'
            }));
        }

        return;
    }

    res.statusCode = 404;

    res.setHeader('Content-Type', 'application/json');

    res.end(JSON.stringify({
        erro: 'Rota não encontrada'
    }));
});

server.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});